/* start signup coding */

var signup_frm = document.getElementById("signup_frm")

signup_frm.onsubmit = function()
{
    var user = btoa(document.getElementById("username").value);
    var email = btoa(document.getElementById("email").value);
    var pass = btoa(document.getElementById("password").value);
    var phone = btoa(document.getElementById("phone").value);

    var user_object_data = {username:user,email:email,password:pass,phone:phone};
    var user_text_data = JSON.stringify(user_object_data);

    if(user != "" && email != "" && pass != "" && phone != "")
    {
        localStorage.setItem(email , user_text_data);
        var signup_btn = document.getElementById("signup_btn");
        signup_btn.style.background = "#0f9b0f";
        signup_btn.innerHTML = "<i class='far fa-check-circle'></i> Sign up Successful !"
        setTimeout(() => {
            signup_btn.style.background = "linear-gradient(to right, #E100FF, #7F00FF)";
            signup_btn.innerHTML = "Sign up";
            signup_frm.reset();
        },2000);
        return false;
    }

}
/* end  signup coding */

/* start email validation coding */
var email_input = document.getElementById("email");
email_input.onchange = function()
{
    var email = btoa(document.getElementById("email").value);
    var email_notice = document.getElementById("email_notice")
    var signup_btn = document.getElementById("signup_btn");
    if(localStorage.getItem(email)!= null)
    {
        email_notice.style.display = "block";
        email_input.style.borderBottomColor = "red";
        signup_btn.disabled = true;
        signup_btn.style.background ="#ccc"

        email_input.onclick = function()
        {
            email_input.value = ""
            email_notice.style.display = "none";
            email_input.style.borderBottomColor = "#ccc";
            signup_btn.style.background ="linear-gradient(to right, #E100FF, #7F00FF)";
            signup_btn.disabled = false;
        }
    }
}
/* end email validation coding */

/* start login coding */
var login_frm = document.getElementById("login_frm")

login_frm.onsubmit = function()
{
    var email = document.getElementById("login_email");
    var password = document.getElementById("login_password");
    var login_email_warning = document.getElementById("login_email_warning");
    var login_password_warning = document.getElementById("login_password_warning");
    if(localStorage.getItem(btoa(email.value)) == null)
    {
        login_email_warning.style.display = "block";
        email.style.borderBottomColor = "red";

        email.onclick = function() 
        {
            login_email_warning.style.display = "none";
            email.style.borderBottomColor = "#ccc"
            email.value="";
        }
    }
    else
    {
        var text_data = localStorage.getItem(btoa(email.value));
        var obj_data = JSON.parse(text_data);
        var correct_email = obj_data.email;
        var correct_password = obj_data.password;
        if(btoa(email.value) == correct_email)
        {
            if(btoa(password.value) == correct_password)
            {
                sessionStorage.setItem("user",btoa(email.value));
                window.location.replace("profile/profile.html")
            }
            else
            {
                login_password_warning.style.display = "block";
                password.style.borderBottomColor = "red";

                password.onclick = function() 
                {
                    password.value="";
                    login_password_warning.style.display = "none";
                    password.style.borderBottomColor = "#ccc"
                }
            }
        }
    }
    return false;
}
/* end login coding */